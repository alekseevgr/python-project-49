### Hexlet tests and linter status:
[![Actions Status](https://github.com/alekseevgr/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/alekseevgr/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/4ced3a4070da9c62c692/maintainability)](https://codeclimate.com/github/alekseevgr/python-project-49/maintainability) ~[![Test Coverage](https://api.codeclimate.com/v1/badges/4ced3a4070da9c62c692/test_coverage)](https://codeclimate.com/github/alekseevgr/python-project-49/test_coverage)


Примеры

Проверка на четность:
[![asciicast](https://asciinema.org/a/efFZHXupsVfjucw3YRllYZZyT.svg)](https://asciinema.org/a/efFZHXupsVfjucw3YRllYZZyT)

Калькулятор:
[![asciicast](https://asciinema.org/a/GpcluG3og0A10Rhgluaq8ajgG.svg)](https://asciinema.org/a/GpcluG3og0A10Rhgluaq8ajgG)

Наибольший общий делитель:
[![asciicast](https://asciinema.org/a/IwzX97nVci2rkZt4eHhxS8mp0.svg)](https://asciinema.org/a/IwzX97nVci2rkZt4eHhxS8mp0)

