from brain_games.games.progression import run_prog_game


def main():
    run_prog_game()


if __name__ == '__main__':
    main()
